# Aleatorio
Atividades referentes a matéria de lógica de programação da P2
